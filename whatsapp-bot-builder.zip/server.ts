import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Define server-side configurations in-memory
interface BotConfig {
  name: string;
  type: "echo" | "faq" | "ai" | "menu";
  aiInstructions: string;
  faqList: { keyword: string; response: string }[];
  menuText: string;
}

let activeConfig: BotConfig = {
  name: "WaBot AI",
  type: "ai",
  aiInstructions: "You are a helpful and polite WhatsApp assistant. Keep your responses short and to the point (no more than 2 sentences). Include a helpful emoji.",
  faqList: [
    { keyword: "hours", response: "🕒 Our business hours are Mon-Fri, 9:00 AM - 5:00 PM EST. Stop by anytime!" },
    { keyword: "price", response: "💰 Our starter plan is completely free! Growth plans start at $9.99/mo." },
    { keyword: "contact", response: "📧 You can reach us at anytime via support@whatsappbot.co." }
  ],
  menuText: "Welcome to Our WhatsApp Bot! 🤖\n\nReply with one of the following numbers:\n1️⃣ Our Business Hours\n2️⃣ Pricing & Plans\n3️⃣ Talk to AI\n4️⃣ Direct Contact Info"
};

// Simple log buffer for webhook events
interface WebhookLog {
  id: string;
  timestamp: string;
  type: "incoming" | "outgoing" | "system";
  source: "simulator" | "twilio";
  message: string;
  payload: any;
}

let webhookLogs: WebhookLog[] = [];

function addLog(type: "incoming" | "outgoing" | "system", source: "simulator" | "twilio", message: string, payload: any) {
  webhookLogs.push({
    id: Math.random().toString(36).substring(7),
    timestamp: new Date().toISOString(),
    type,
    source,
    message,
    payload
  });
  // Keep last 50 logs
  if (webhookLogs.length > 50) {
    webhookLogs.shift();
  }
}

// Initialize GoogleGenAI client if API key is present
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
  addLog("system", "simulator", "Gemini AI Engine live! Setup is reading GEMINI_API_KEY from secrets.", { status: "ready" });
} else {
  addLog("system", "simulator", "Gemini API Key missing in environment. Using locally-generated smart chatbot mock responses.", { status: "limited" });
}

async function handleBotLogic(messageText: string, fromNumber: string, isFromTwilio: boolean): Promise<string> {
  const normalizedMsg = messageText.trim().toLowerCase();
  const source = isFromTwilio ? "twilio" : "simulator";

  addLog("incoming", source, `Message from ${fromNumber}: "${messageText}"`, {
    from: fromNumber,
    body: messageText
  });

  let replyText = "";

  if (activeConfig.type === "echo") {
    replyText = `📢 Echo payload: "${messageText}"`;
  } else if (activeConfig.type === "menu") {
    // Check if reply maps to digits or keywords
    if (normalizedMsg === "1" || normalizedMsg.includes("hours") || normalizedMsg.includes("business")) {
      replyText = "🕒 Business Hours: We are open Mon-Fri, 9:00 AM - 5:00 PM EST.";
    } else if (normalizedMsg === "2" || normalizedMsg.includes("price") || normalizedMsg.includes("pricing") || normalizedMsg.includes("plan")) {
      replyText = "💰 Pricing: Free tier is $0/永远. Growth tiers start at $9.99/month.";
    } else if (normalizedMsg === "3" || normalizedMsg.includes("ai") || normalizedMsg.includes("talk")) {
      replyText = "🤖 Setting up brain cell... Ready! Ask me anything, I am your continuous AI companion.";
    } else if (normalizedMsg === "4" || normalizedMsg.includes("contact") || normalizedMsg.includes("email") || normalizedMsg.includes("support")) {
      replyText = "📧 Support: Email us at support@whatsappbot.co or visit whatsappbot.co/support.";
    } else {
      replyText = activeConfig.menuText;
    }
  } else if (activeConfig.type === "faq") {
    // Direct matches or substring checks
    const match = activeConfig.faqList.find(item => 
      normalizedMsg.includes(item.keyword.toLowerCase())
    );
    if (match) {
      replyText = match.response;
    } else {
      replyText = "⚠️ Sorry, I didn't recognize that word. Try keywords: hours, price, contact.";
    }
  } else if (activeConfig.type === "ai") {
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: messageText,
          config: {
            systemInstruction: activeConfig.aiInstructions,
          }
        });
        replyText = response.text || "Sorry, I had trouble parsing my AI thoughts.";
      } catch (err: any) {
        replyText = `🤖 Gemini reply fallback: "Hello there! My system instruction is telling me to be: ${activeConfig.aiInstructions}"`;
        addLog("system", source, `AI processing error: ${err.message}`, { error: err });
      }
    } else {
      // High quality simulation fallback using actual config
      const mockResponses = [
        `🤖 [Local Mock AI] That is very interesting! As per my system instruction (${activeConfig.aiInstructions.substring(0, 45)}...), I am confirming receipt of your message: "${messageText}".`,
        `🤖 [Local Mock AI] Hello! Processing message "${messageText}" under rule: "${activeConfig.aiInstructions.substring(0, 40)}". Have a wonderful day! ✨`,
        `🤖 [Local Mock AI] Beep Boop! Quick answer: I read your query "${messageText}" and I'm feeling helpful! Let me know if you need more tips!`
      ];
      replyText = mockResponses[Math.floor(Math.random() * mockResponses.length)];
    }
  }

  addLog("outgoing", source, `Sent automated reply: "${replyText}"`, {
    to: fromNumber,
    reply: replyText
  });

  return replyText;
}

// Start Express server
const app = express();
const PORT = 3000;

// Enable body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// REST API Endpoints
app.get("/api/bot-config", (req, res) => {
  res.json(activeConfig);
});

app.post("/api/bot-config", (req, res) => {
  activeConfig = { ...activeConfig, ...req.body };
  addLog("system", "simulator", `Updated Bot configuration successfully. Active Profile: ${activeConfig.name} (${activeConfig.type.toUpperCase()})`, { config: activeConfig });
  res.json({ success: true, config: activeConfig });
});

app.get("/api/logs", (req, res) => {
  res.json(webhookLogs);
});

app.post("/api/logs/clear", (req, res) => {
  webhookLogs = [];
  res.json({ success: true });
});

// Simulated direct message route for the visual sandbox UI
app.post("/api/simulate-chat", async (req, res) => {
  const { message, from } = req.body;
  const reply = await handleBotLogic(message || "", from || "+123456789", false);
  res.json({ reply });
});

// Live Webhook compatible with Twilio (POST /api/whatsapp-webhook)
app.post("/api/whatsapp-webhook", async (req, res) => {
  const incomingMsg = req.body.Body || "";
  const fromNumber = req.body.From || "";
  
  // Format response in XML TwiML format
  const replyText = await handleBotLogic(incomingMsg, fromNumber, true);
  
  res.set("Content-Type", "text/xml");
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Message>${replyText.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</Message>
</Response>`;
  res.send(twiml);
});

// Configure Dev and Prod Web Assets Serve
async function initServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

initServer();
