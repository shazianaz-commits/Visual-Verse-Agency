import { BotConfig } from "./types";

export function getPythonAppCode(config: BotConfig): string {
  if (config.type === "echo") {
    return `from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

@app.route("/webhook", methods=["POST"])
def webhook():
    # Retrieve incoming message text sent by Twilio webhook
    incoming_msg = request.values.get('Body', '').strip()
    
    # Prepare Twilio messaging response (TwiML XML response)
    resp = MessagingResponse()
    msg = resp.message()
    
    # Echo the message back
    msg.body(f"📢 Echo payload: {incoming_msg}")
    
    return str(resp)

if __name__ == "__main__":
    # Standard local debug server (defaults to port 5000)
    app.run(host="0.0.0.0", port=5000, debug=True)
`;
  }

  if (config.type === "menu") {
    return `from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

# Configured menu response
MENU_TEXT = """${config.menuText.replace(/"/g, '\\"')}"""

@app.route("/webhook", methods=["POST"])
def webhook():
    # Get user's incoming message and lowercase it for easy matching
    incoming_msg = request.values.get('Body', '').strip().lower()
    
    resp = MessagingResponse()
    msg = resp.message()
    
    if incoming_msg == "1" or "hours" in incoming_msg:
        msg.body("🕒 Business Hours: We are open Mon-Fri, 9:00 AM - 5:00 PM EST.")
    elif incoming_msg == "2" or "price" in incoming_msg or "pricing" in incoming_msg:
        msg.body("💰 Pricing: Free tier is $0. Growth packages start at $9.99/month.")
    elif incoming_msg == "3" or "ai" in incoming_msg or "talk" in incoming_msg:
        msg.body("🤖 AI Setup is active! Ask me anything, I am your continuous AI companion.")
    elif incoming_msg == "4" or "contact" in incoming_msg or "support" in incoming_msg:
        msg.body("📧 Support: Email us at support@whatsappbot.co or visit whatsappbot.co/support.")
    else:
        # Fallback to the primary text menu options
        msg.body(MENU_TEXT)
        
    return str(resp)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
`;
  }

  if (config.type === "faq") {
    const pythonFaqDict = config.faqList
      .map(item => `    "${item.keyword.toLowerCase().replace(/"/g, '\\"')}": "${item.response.replace(/"/g, '\\"')}"`)
      .join(",\n");

    return `from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

# Dynamic key-value pairs of your configured FAQs
FAQ_DATA = {
${pythonFaqDict}
}

@app.route("/webhook", methods=["POST"])
def webhook():
    incoming_msg = request.values.get('Body', '').strip().lower()
    
    resp = MessagingResponse()
    msg = resp.message()
    
    # Check trigger words inside user message
    matched = False
    for keyword, reply in FAQ_DATA.items():
        if keyword in incoming_msg:
            msg.body(reply)
            matched = True
            break
            
    if not matched:
        msg.body("⚠️ Sorry, keyword not matched. Trigger words available: " + ", ".join(FAQ_DATA.keys()))
        
    return str(resp)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
`;
  }

  // AI model (with Gemini using modern @google-genai SDK equivalent syntax in python)
  return `import os
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from google import genai
from google.genai import types

app = Flask(__name__)

# Initialize the Gemini GenAI Client
# Automatically reads the GEMINI_API_KEY environment variable
client = genai.Client()

SYSTEM_INSTRUCTION = """${config.aiInstructions.replace(/"/g, '\\"')}"""

@app.route("/webhook", methods=["POST"])
def webhook():
    incoming_msg = request.values.get('Body', '').strip()
    
    resp = MessagingResponse()
    msg = resp.message()
    
    try:
        # Call Google's latest Gemini 3.5 Flash model
        response = client.models.generate_content(
            model="gemini-3.5-flash",
            contents=incoming_msg,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION
            )
        )
        reply_text = response.text
    except Exception as e:
        print(f"Error accessing Gemini AI: {e}")
        # Standard polite offline fallback
        reply_text = "🤖 Sorry! My AI neurons are momentarily offline. Please send your question again in a moment!"
        
    msg.body(reply_text)
    return str(resp)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
`;
}

export const requirementsTxt = `Flask==3.0.3
twilio==9.1.1
google-genai==0.3.0
gunicorn==22.0.0
python-dotenv==1.0.1
`;

export const envExample = `# WhatsApp Bot Secrets
# Paste your twilio Auth details (Optional for simple standard bots)
TWILIO_ACCOUNT_SID=ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_AUTH_TOKEN=your_auth_token_here

# Required for AI Brain capability. Get yours at https://aistudio.google.com/
GEMINI_API_KEY=AIzaSyYourGeminiApiKeyHere
`;

export const procfile = `web: gunicorn app:app
`;

export interface GuideStep {
  title: string;
  description: string;
  details: string[];
}

export const guideSteps: GuideStep[] = [
  {
    title: "1. Establish a Free Twilio WhatsApp Sandbox",
    description: "Get a free virtual phone number from Twilio configured with the WhatsApp Sandbox API.",
    details: [
      "Access the official Twilio Console (twilio.com) and create a free account. No credit card required.",
      "Navigate to Messaging > Try it out > Send a WhatsApp message in your console.",
      "Agree to the Sandbox terms to receive your standard Sandbox telephone number and unique invitation activation message (e.g., 'join simple-pathway').",
      "Send that activation text from your personal WhatsApp account to the Twilio number to establish communication."
    ]
  },
  {
    title: "2. Set Up Local Python Environment",
    description: "Set up your workspace with Python and install essential helper dependencies.",
    details: [
      "Create a local project folder and initialize a virtual environment: `python3 -m venv venv`.",
      "Activate it: `source venv/bin/activate` or `venv\\Scripts\\activate` on Windows.",
      "Create a file named `requirements.txt` and copy the dependencies from the project tab.",
      "Install dependencies with: `pip install -r requirements.txt`.",
      "Store your secret keys inside a `.env` file at the root of the project."
    ]
  },
  {
    title: "3. Run and Tunnel code with ngrok",
    description: "Accept incoming requests locally by tunneling them to Twilio during development.",
    details: [
      "Run your python application locally: `python app.py`. Your server starts listening at `http://127.0.0.1:5000`.",
      "Download and install ngrok, a completely free local networking tool.",
      "Run ngrok to expose your local port: `ngrok http 5000`.",
      "ngrok generates a secure public live URL (e.g., `https://abcdef123.ngrok-free.app`).",
      "Copy this URL. Inside your Twilio Sandbox console, locate 'When a message comes in' and paste your new URL appended with `/webhook` (e.g. `https://abcdef123.ngrok-free.app/webhook`). Click Save!"
    ]
  },
  {
    title: "4. Deploy continuously on Free Cloud (Render)",
    description: "Move your app from your computer to Render.com's continuous free tier to keep the bot alive 24/7.",
    details: [
      "Create a free developer account at Render.com.",
      "Create a new 'Web Service' and link your GitHub repository containing the Python bot files (`app.py`, `requirements.txt`, and `Procfile` if applicable).",
      "Select Python 3 as your environment.",
      "Set Command to start the app: `gunicorn app:app` (Make sure gunicorn is in your requirements.txt).",
      "Under 'Environment Variables' settings, add `GEMINI_API_KEY` and any relevant twilio config credentials.",
      "Click Deploy. Render compiles the code and spawns a public address like `https://my-whatsapp-bot.onrender.com`.",
      "Now, go replace the temporary ngrok URL in your Twilio Sandbox dashboard with this live continuous Render production URL: `https://my-whatsapp-bot.onrender.com/webhook`! Your bot is now live 24/7 for FREE!"
    ]
  }
];
