import React, { useState, useEffect, useRef } from "react";
import { 
  Bot, 
  MessageSquare, 
  Code, 
  FileText, 
  Terminal, 
  Play, 
  Copy, 
  Check, 
  RefreshCw, 
  Trash2, 
  Layers, 
  BookOpen, 
  Settings, 
  PhoneCall, 
  Cpu, 
  Send,
  Plus,
  Minus,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  Sparkles,
  CheckCheck,
  AlertCircle
} from "lucide-react";
import { BotConfig, BotType, WebhookLog, ChatMessage } from "./types";
import { getPythonAppCode, requirementsTxt, envExample, procfile, guideSteps } from "./data";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // Configured state
  const [config, setConfig] = useState<BotConfig>({
    name: "WaBot AI",
    type: "ai",
    aiInstructions: "You are a helpful and polite WhatsApp assistant. Keep your responses short and to the point (no more than 2 sentences). Include a helpful emoji.",
    faqList: [
      { keyword: "hours", response: "🕒 Our business hours are Mon-Fri, 9:00 AM - 5:00 PM EST. Stop by anytime!" },
      { keyword: "price", response: "💰 Our starter plan is completely free! Growth plans start at $9.99/mo." },
      { keyword: "contact", response: "📧 You can reach us at anytime via support@whatsappbot.co." }
    ],
    menuText: "Welcome to Our WhatsApp Bot! 🤖\n\nReply with one of the following numbers:\n1️⃣ Our Business Hours\n2️⃣ Pricing & Plans\n3️⃣ Talk to AI\n4️⃣ Direct Contact Info"
  });

  const [activeTab, setActiveTab] = useState<"workspace" | "sandbox" | "guide">("sandbox");
  const [activeCodeFile, setActiveCodeFile] = useState<"app.py" | "requirements.txt" | ".env" | "Procfile">("app.py");
  const [logs, setLogs] = useState<WebhookLog[]>([]);
  const [systemUptime, setSystemUptime] = useState<number>(0);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: "1", sender: "bot", text: "Hello! Welcome to the automated WhatsApp Sandbox sandbox system. Try sending me a message to test the bot logic configured on the left panel!", timestamp: "08:30" }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("+14155552671");
  const [faqKeywordInput, setFaqKeywordInput] = useState("");
  const [faqResponseInput, setFaqResponseInput] = useState("");
  const [isCopied, setIsCopied] = useState<string | null>(null);
  const [isDeploying, setIsDeploying] = useState(false);
  const [isSimulatingResponse, setIsSimulatingResponse] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isScrollLocked, setIsScrollLocked] = useState(true);

  const logsEndRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Fetch initial config and logs
  useEffect(() => {
    fetchConfig();
    fetchLogs();
    const interval = setInterval(() => {
      fetchLogs();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Set system timer
  useEffect(() => {
    const timer = setInterval(() => {
      setSystemUptime(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Auto scroll to bottom of logs if lock is enabled
  useEffect(() => {
    if (isScrollLocked && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs, isScrollLocked]);

  // Auto scroll chat
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages]);

  const fetchConfig = async () => {
    try {
      const res = await fetch("/api/bot-config");
      const data = await res.json();
      if (data && data.name) {
        setConfig(data);
      }
    } catch (e) {
      console.error("Failed to load bot configuration.", e);
    }
  };

  const fetchLogs = async () => {
    try {
      const res = await fetch("/api/logs");
      const data = await res.json();
      if (Array.isArray(data)) {
        setLogs(data);
      }
    } catch (e) {
      console.error("Failed to load webhook logs.", e);
    }
  };

  const saveConfiguration = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsDeploying(true);
    try {
      const res = await fetch("/api/bot-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (data.success) {
        setHasUnsavedChanges(false);
        // Show success alert
        fetchLogs();
      }
    } catch (err) {
      console.error("Failed to post config updates", err);
    } finally {
      setTimeout(() => {
        setIsDeploying(false);
      }, 700);
    }
  };

  const handleConfigChange = <K extends keyof BotConfig>(key: K, value: BotConfig[K]) => {
    setConfig(prev => ({ ...prev, [key]: value }));
    setHasUnsavedChanges(true);
  };

  const clearServerLogs = async () => {
    try {
      await fetch("/api/logs/clear", { method: "POST" });
      setLogs([]);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSimulationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isSimulatingResponse) return;

    const userText = inputMessage;
    const userMsgId = Math.random().toString();
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Append user message
    const userMsg: ChatMessage = {
      id: userMsgId,
      sender: "user",
      text: userText,
      timestamp: formattedTime
    };

    setChatMessages(prev => [...prev, userMsg]);
    setInputMessage("");
    setIsSimulatingResponse(true);

    try {
      // Simulate endpoint request
      const res = await fetch("/api/simulate-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText, from: phoneNumber })
      });
      const data = await res.json();
      
      const botResponseTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const botMsg: ChatMessage = {
        id: Math.random().toString(),
        sender: "bot",
        text: data.reply || "🤖 [Sandbox Error] Response timed out.",
        timestamp: botResponseTime
      };

      setChatMessages(prev => [...prev, botMsg]);
      fetchLogs();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSimulatingResponse(false);
    }
  };

  const addFaqItem = () => {
    if (!faqKeywordInput.trim() || !faqResponseInput.trim()) return;
    const newList = [...config.faqList, { 
      keyword: faqKeywordInput.trim(), 
      response: faqResponseInput.trim() 
    }];
    handleConfigChange("faqList", newList);
    setFaqKeywordInput("");
    setFaqResponseInput("");
  };

  const removeFaqItem = (index: number) => {
    const newList = config.faqList.filter((_, i) => i !== index);
    handleConfigChange("faqList", newList);
  };

  const handleCopyCode = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(label);
    setTimeout(() => {
      setIsCopied(null);
    }, 2000);
  };

  // Format uptime string
  const formatUptime = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return [
      hours.toString().padStart(2, '0'),
      minutes.toString().padStart(2, '0'),
      seconds.toString().padStart(2, '0')
    ].join(':');
  };

  // Active Code Representation based on Selected Tab
  const getSelectedCodeText = () => {
    switch (activeCodeFile) {
      case "app.py":
        return getPythonAppCode(config);
      case "requirements.txt":
        return requirementsTxt;
      case ".env":
        return envExample;
      case "Procfile":
        return procfile;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F2ED] text-[#1A1A1A] font-sans flex flex-col relative overflow-x-hidden antialiased selection:bg-[#1A1A1A] selection:text-[#F5F2ED]">
      
      {/* Editorial Border Frames representing physical paper booklet lines */}
      <div className="absolute top-0 bottom-0 left-4 w-px bg-[#1A1A1A] opacity-10 pointer-events-none hidden md:block" />
      <div className="absolute top-0 bottom-0 right-4 w-px bg-[#1A1A1A] opacity-10 pointer-events-none hidden md:block" />

      {/* HEADER SECTION - Strict BOT.MASTER Georgia typeface */}
      <header className="border-b-2 border-[#1A1A1A] px-4 md:px-12 py-6 bg-[#F5F2ED] z-10 sticky top-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-4 md:gap-0">
          <div>
            <div className="flex items-center gap-3">
              <span className="font-serif font-black text-2xl md:text-3xl tracking-tight select-none">
                BOT.MASTER
              </span>
              <span className="text-[10px] font-bold tracking-widest uppercase bg-[#1A1A1A] text-[#F5F2ED] px-2 py-[2px] rounded-xs">
                v2.1
              </span>
            </div>
            <p className="text-[11px] uppercase tracking-wider opacity-60 font-semibold mt-1">
              WhatsApp Cloud Autocraft // Production Workspace
            </p>
          </div>
          
          {/* Quick Stats Grid to establish Editorial Rhythm */}
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-mono font-semibold">
            <div className="flex items-center gap-1.5 border-r border-[#1A1A1A] border-opacity-20 pr-4">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>STANDBY</span>
            </div>
            <div className="flex items-center gap-1 border-r border-[#1A1A1A] border-opacity-20 pr-4">
              <span className="opacity-40">UTC:</span>
              <span>{new Date().toISOString().substring(11, 19)}</span>
            </div>
            <div className="flex items-center gap-1 border-r border-[#1A1A1A] border-opacity-20 pr-4">
              <span className="opacity-40">UPTIME:</span>
              <span>{formatUptime(systemUptime)}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="opacity-40">HOST_COST:</span>
              <span className="bg-emerald-100 text-emerald-800 px-1.5 py-[1px] font-bold rounded-sm">$0.00 / Free</span>
            </div>
          </div>
        </div>
      </header>

      {/* MASTER TOPOLOGY STATS STRIP */}
      <section className="bg-[#1A1A1A] text-[#F5F2ED] border-b border-[#1A1A1A]">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 divide-y divide-x lg:divide-y-0 divide-[#333] tracking-wide font-serif text-sm">
          <div className="p-4 md:px-8 md:py-5 flex flex-col justify-between">
            <span className="text-[10px] font-mono tracking-widest text-[#999] uppercase block mb-1">01 // TARGET ENVIRONMENT</span>
            <div className="text-base md:text-lg font-normal font-sans tracking-tight">Python 3.11 + Flask Server</div>
          </div>
          <div className="p-4 md:px-8 md:py-5 flex flex-col justify-between">
            <span className="text-[10px] font-mono tracking-widest text-[#999] uppercase block mb-1">02 // WEBHOOK GATEWAY</span>
            <div className="text-base md:text-lg font-normal font-sans tracking-tight">Twilio WhatsApp Sandbox</div>
          </div>
          <div className="p-4 md:px-8 md:py-5 flex flex-col justify-between">
            <span className="text-[10px] font-mono tracking-widest text-[#999] uppercase block mb-1">03 // ACTIVE BOT PROFILE</span>
            <div className="text-base md:text-lg font-normal font-sans tracking-tight capitalize text-emerald-400 font-semibold flex items-center gap-1.5">
              <span className="inline-block w-2-2 h-2 rounded-full bg-emerald-400" />
              {config.name} ({config.type})
            </div>
          </div>
          <div className="p-4 md:px-8 md:py-5 flex flex-col justify-between">
            <span className="text-[10px] font-mono tracking-widest text-[#999] uppercase block mb-1">04 // STABILITY PROFILE</span>
            <div className="text-base md:text-lg font-normal font-sans tracking-tight">Render Free Tier (24/7 Alive)</div>
          </div>
        </div>
      </section>

      {/* DUAL WORKSPACE LAYOUT (Side Config & Central Deck) */}
      <main className="flex-1 max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 border-b border-[#1A1A1A] overflow-hidden">
        
        {/* COLUMN 1: INTERACTIVE CONFIGURATION FORM (lg:col-span-5) */}
        <section id="config-panel" className="lg:col-span-5 p-6 md:p-8 border-b lg:border-b-0 lg:border-r border-[#1A1A1A] flex flex-col justify-between bg-[#F2EDE6]">
          <div>
            <div className="flex items-center gap-2 mb-6 pb-2 border-b border-[#1A1A1A] border-opacity-30">
              <Settings className="w-5 h-5 text-[#1A1A1A] stroke-[1.5]" />
              <h2 className="font-serif font-bold text-xl tracking-tight text-[#1A1A1A]">Configure Bot Parameters</h2>
            </div>

            <form onSubmit={saveConfiguration} className="space-y-6">
              
              {/* Bot Meta Information */}
              <div className="space-y-2">
                <label className="text-xs font-mono font-bold uppercase tracking-wider block">
                  A. Bot Identity Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={config.name}
                    onChange={(e) => handleConfigChange("name", e.target.value)}
                    className="w-full bg-[#F5F2ED] border border-[#1A1A1A] px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#1A1A1A] font-medium"
                    placeholder="e.g. HelpDesk Bot"
                    required
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-opacity-50 text-[#1A1A1A] font-mono">ID</span>
                </div>
                <p className="text-[11px] text-[#555]">This assigns structural log names and sets class descriptors inside the Python templates.</p>
              </div>

              {/* Bot Logical Type Select */}
              <div className="space-y-3">
                <label className="text-xs font-mono font-bold uppercase tracking-wider block">
                  B. Bot Behavioral Brain Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "ai", label: "Gemini AI Brain", desc: "Intelligent conversations", icon: Sparkles, color: "border-purple-800 text-purple-900 bg-purple-50/40" },
                    { id: "menu", label: "Menu Options", desc: "Keypress interactive rules", icon: Layers, color: "border-blue-800 text-blue-900 bg-blue-50/40" },
                    { id: "faq", label: "FAQ Matcher", desc: "Trigger word matching", icon: FileText, color: "border-cyan-800 text-cyan-900 bg-cyan-50/40" },
                    { id: "echo", label: "Echo Telemetry", desc: "Repeats sender payload", icon: MessageSquare, color: "border-amber-800 text-amber-900 bg-amber-50/40" },
                  ].map((btn) => {
                    const isSelected = config.type === btn.id;
                    const IconComponent = btn.icon;
                    return (
                      <button
                        key={btn.id}
                        type="button"
                        onClick={() => handleConfigChange("type", btn.id as BotType)}
                        className={`text-left p-3 border rounded-xs transition-all ${
                          isSelected 
                            ? `${btn.color} border-2 ring-1 ring-black/10 scale-[1.01] font-bold` 
                            : "border-[#1A1A1A] border-opacity-30 hover:border-opacity-100 hover:bg-[#F5F2ED]"
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <IconComponent className={`w-4 h-4 ${isSelected ? "stroke-[2.5]" : "stroke-[1.5]"}`} />
                          <span className="text-xs uppercase font-mono tracking-tight font-black">{btn.label}</span>
                        </div>
                        <p className="text-[10px] opacity-70 mt-1 leading-tight">{btn.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* DYNAMIC FORM SEGMENTS BASED ON BOT TYPE */}
              <div className="border border-[#1A1A1A] p-4 bg-[#F5F2ED] rounded-xs space-y-4">
                <span className="text-[10px] font-mono tracking-widest text-opacity-60 text-[#1A1A1A] uppercase block border-b border-[#1A1A1A] border-opacity-15 pb-1">
                  Logical Engine Configuration - {config.type.toUpperCase()}
                </span>

                {/* 1. ECHO OPTIONS */}
                {config.type === "echo" && (
                  <div className="space-y-2">
                    <p className="text-xs text-[#1A1A1A] opacity-80 leading-relaxed font-serif">
                      The active bot will inspect incoming requests and automatically formulate replies repeating the exactly received WhatsApp packet strings. Useful for rapid Twilio integration dry-runs.
                    </p>
                    <div className="p-3 bg-neutral-100 border border-neutral-300 font-mono text-[11px] rounded-sm text-neutral-600">
                      Response: <span className="italic block mt-1">"📢 Echo payload: 'User message here'"</span>
                    </div>
                  </div>
                )}

                {/* 2. FAQ KEYWORD MATCHES */}
                {config.type === "faq" && (
                  <div className="space-y-3">
                    <div className="space-y-1.5">
                      <p className="text-xs text-[#555] font-serif leading-relaxed">
                        Specify simple sub-string words that trigger standard canned replies. Keep matching strict to prevent overlapping criteria.
                      </p>
                      
                      {/* Active Keywords List */}
                      {config.faqList.length === 0 ? (
                        <div className="p-3 border border-dashed border-[#1A1A1A] border-opacity-30 text-center text-xs opacity-60">
                          Empty database. Add trigger words below.
                        </div>
                      ) : (
                        <div className="max-h-48 overflow-y-auto divide-y divide-[#1A1A1A] divide-opacity-30 border border-[#1A1A1A] text-xs">
                          {config.faqList.map((item, idx) => (
                            <div key={idx} className="p-2.5 flex justify-between items-start bg-white/50">
                              <div className="space-y-1 pr-4">
                                <span className="font-mono bg-[#1A1A1A] text-[#F5F2ED] px-1 py-0.5 rounded-sm text-[10px] uppercase font-bold mr-2">
                                  {item.keyword}
                                </span>
                                <p className="text-[#333] leading-normal">{item.response}</p>
                              </div>
                              <button
                                type="button"
                                onClick={() => removeFaqItem(idx)}
                                className="text-red-700 hover:text-red-950 p-1 font-mono uppercase text-[9px] font-bold border border-red-700/20 hover:border-red-950/80 rounded-sm"
                              >
                                REMOVE
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* FAQ Inputs */}
                    <div className="bg-white p-3 border border-[#1A1A1A] space-y-2.5">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-[#1A1A1A]/70 block font-bold">Add FAQ Rule Entry</span>
                      <div className="grid grid-cols-12 gap-2">
                        <div className="col-span-4">
                          <input
                            type="text"
                            placeholder="Keyword (e.g. price)"
                            value={faqKeywordInput}
                            onChange={(e) => setFaqKeywordInput(e.target.value)}
                            className="w-full bg-[#F5F2ED] border border-[#1A1A1A] px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#1A1A1A] font-mono uppercase"
                          />
                        </div>
                        <div className="col-span-8">
                          <input
                            type="text"
                            placeholder="WhatsApp response text content"
                            value={faqResponseInput}
                            onChange={(e) => setFaqResponseInput(e.target.value)}
                            className="w-full bg-[#F5F2ED] border border-[#1A1A1A] px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#1A1A1A]"
                          />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={addFaqItem}
                        disabled={!faqKeywordInput.trim() || !faqResponseInput.trim()}
                        className="w-full bg-[#1A1A1A] text-[#F5F2ED] px-3 py-1.5 text-xs font-mono font-bold uppercase hover:bg-neutral-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" /> Inject Trigger Rule
                      </button>
                    </div>
                  </div>
                )}

                {/* 3. INTERACTIVE CHOOSE MENU */}
                {config.type === "menu" && (
                  <div className="space-y-3">
                    <p className="text-xs text-[#555] font-serif leading-relaxed">
                      This models standard numbered menu options (e.g., reply with 1, 2, or 3). Customize your directory structure.
                    </p>
                    <div className="space-y-1">
                      <span className="text-[11px] font-mono font-bold uppercase text-[#1A1A1A] block">Primary Welcomer Menu List:</span>
                      <textarea
                        value={config.menuText}
                        onChange={(e) => handleConfigChange("menuText", e.target.value)}
                        rows={6}
                        className="w-full bg-white border border-[#1A1A1A] p-2.5 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-[#1A1A1A] leading-normal"
                        required
                      />
                    </div>
                    <div className="text-[10px] text-neutral-500 font-mono bg-white p-2 border border-[#1A1A1A] border-opacity-30">
                      ℹ️ Pressing numbers in the WhatsApp interactive simulation will trigger respective details: "1" = Hours, "2" = Pricing, "3" = AI trigger, "4" = Support info.
                    </div>
                  </div>
                )}

                {/* 4. CONTINUOUS GEMINI AI BRAIN */}
                {config.type === "ai" && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[11px] font-mono font-bold uppercase text-purple-950 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 fill-purple-300 stroke-purple-950" /> System Instructions Prompter:
                      </span>
                      <span className="text-[10px] py-[1px] px-1.5 bg-purple-100 text-purple-800 uppercase font-mono font-bold rounded-sm">
                        {process.env.GEMINI_API_KEY ? "Live API Connected" : "Local Smart Simulation"}
                      </span>
                    </div>
                    <p className="text-xs text-[#555] font-serif leading-relaxed">
                      Give the Gemini 3.5 Flash neural brain specific personality constraints, length boundaries, or answers database rules.
                    </p>
                    <textarea
                      value={config.aiInstructions}
                      onChange={(e) => handleConfigChange("aiInstructions", e.target.value)}
                      rows={4}
                      className="w-full bg-white border border-[#1A1A1A] p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#1A1A1A] leading-relaxed"
                      required
                    />
                    <div className="pt-1.5 border-t border-[#1A1A1A]/10 flex flex-wrap gap-1">
                      <span className="text-[9px] font-mono text-neutral-500 self-center mr-1">Tones:</span>
                      {[
                        { name: "Friendly Helper", text: "You are a warm, polite assistant. Keep your responses short (no more than 2 sentences). Use helpful friendly emojis!" },
                        { name: "Sassy & Quick", text: "You are lightheartedly sarcastic, extremely witty, and highly concise in responses. Never write more than 1 sentence." },
                        { name: "Technical Documentor", text: "You are a professional systems engineer. Provide crisp diagnostic answers with exact precision." },
                      ].map((preset, pidx) => (
                        <button
                          key={pidx}
                          type="button"
                          onClick={() => handleConfigChange("aiInstructions", preset.text)}
                          className="text-[9px] font-mono bg-white hover:bg-purple-50 text-neutral-700 px-1.5 py-0.5 border border-[#1A1A1A] border-opacity-30 rounded-xs"
                        >
                          {preset.name}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* ACTION: COMPOSE & SAVE CONFIG */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isDeploying}
                  className={`w-full py-4 text-xs font-mono font-bold tracking-widest uppercase transition-all flex items-center justify-center gap-2 ${
                    hasUnsavedChanges
                      ? "bg-[#1A1A1A] text-[#F5F2ED] hover:bg-neutral-800 ring-4 ring-[#1A1A1A]/10"
                      : "bg-[#E2DCCF] text-[#444] border border-[#1A1A1A]/50 cursor-default"
                  }`}
                >
                  {isDeploying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" /> Compiling Logic Framework...
                    </>
                  ) : hasUnsavedChanges ? (
                    <>
                      <Cpu className="w-4 h-4 fill-emerald-300 text-white" /> Compile & Deploy Changes
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" /> Ready to Test (Standby)
                    </>
                  )}
                </button>
                {hasUnsavedChanges && (
                  <div className="flex gap-1.5 items-center justify-center text-amber-800 text-[10px] font-mono uppercase mt-2.5 font-bold animate-pulse">
                    <AlertCircle className="w-3.5 h-3.5" /> Configuration altered. Deploy to update code and endpoints.
                  </div>
                )}
              </div>

            </form>
          </div>

          {/* Quick Technical Schema Diagram */}
          <div className="mt-8 pt-6 border-t border-[#1A1A1A] border-opacity-20 text-xs">
            <span className="font-mono font-bold text-[10px] text-[#1A1A1A]/70 uppercase block mb-3">Logical Schema Dataflow:</span>
            <div className="grid grid-cols-4 gap-1 text-center font-mono text-[9px] text-[#333]">
              <div className="p-1 px-1.5 bg-white border border-[#1A1A1A]/30">
                <span className="font-bold uppercase text-[8px] block">WhatsApp</span>
                Sim/Device
              </div>
              <div className="flex items-center justify-center opacity-60">──►</div>
              <div className="p-1 px-1.5 bg-white border border-[#1A1A1A]/30 font-bold">
                <span className="text-[8px] block font-normal">Twilio Webhook</span>
                API Router
              </div>
              <div className="p-1 px-1.5 bg-[#1F2937] text-white border border-[#1A1A1A]/30">
                <span className="text-[8px] text-emerald-400 block font-normal">Flask Server</span>
                Continuous
              </div>
            </div>
          </div>

        </section>

        {/* COLUMN 2: DECK AND WORKSPACES - THREE MAIN INTERCHANGABLE INTERFACES (lg:col-span-7) */}
        <section className="lg:col-span-7 flex flex-col justify-between bg-[#F5F2ED]">
          
          {/* TAB TAPE CONTROLLER */}
          <div className="border-b border-[#1A1A1A] bg-[#E8E4DF] flex justify-between items-stretch">
            <div className="flex divide-x divide-[#1A1A1A] font-mono text-xs font-bold uppercase">
              {[
                { id: "sandbox", label: "01 // WhatsApp Sim", icon: MessageSquare, badge: "TEST" },
                { id: "workspace", label: "02 // Python Codebase", icon: Code, badge: "GET" },
                { id: "guide", label: "03 // Continuous Cloud Guide", icon: BookOpen, badge: "FREE" }
              ].map(t => {
                const isSel = activeTab === t.id;
                const TabIcon = t.icon;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setActiveTab(t.id as any)}
                    className={`px-4 md:px-6 py-4 flex items-center gap-2 transition-all cursor-pointer ${
                      isSel 
                        ? "bg-[#F5F2ED] border-b-2 border-b-[#1A1A1A] font-black tracking-tight" 
                        : "opacity-70 hover:opacity-100 hover:bg-[#F2EDE6]"
                    }`}
                  >
                    <TabIcon className="w-4 h-4 stroke-[1.5]" />
                    <span>{t.label}</span>
                    <span className="hidden sm:inline-block text-[8px] bg-[#1A1A1A] text-[#F5F2ED] px-1 py-[1px] font-mono leading-none rounded-xs">{t.badge}</span>
                  </button>
                );
              })}
            </div>

            {/* Quick Helper External Launcher Links */}
            <div className="hidden md:flex divide-x divide-[#1A1A1A] border-l border-[#1A1A1A] font-mono text-[10px] items-stretch uppercase font-bold text-neutral-600">
              <a 
                href="https://console.twilio.com" 
                target="_blank" 
                rel="noreferrer" 
                className="px-4 py-3 hover:bg-[#F2EDE6] hover:text-black flex items-center gap-1.5 self-center h-full"
              >
                <span>Twilio</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <a 
                href="https://render.com" 
                target="_blank" 
                rel="noreferrer" 
                className="px-4 py-3 hover:bg-[#F2EDE6] hover:text-black flex items-center gap-1.5 self-center h-full animate-pulse text-emerald-800"
              >
                <span>Render free</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* CHOSEN COMPONENT DECK SCREEN */}
          <div className="p-6 md:p-8 flex-1 flex flex-col justify-between min-h-[460px]">
            <AnimatePresence mode="wait">
              
              {/* TAB 1: SMARTPHONE INTERACTIVE SIMULATOR */}
              {activeTab === "sandbox" && (
                <motion.div
                  key="sandbox"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="space-y-6 flex-1 flex flex-col"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#1A1A1A]/20 pb-4 gap-3 sm:gap-0">
                    <div>
                      <h3 className="font-serif font-black text-2xl tracking-tight">Virtual WhatsApp Sandbox Sim</h3>
                      <p className="text-xs text-[#555] font-serif">Simulate Twilio WhatsApp webhook packets directly inside this browser. Change values dynamically inside left panel.</p>
                    </div>

                    <div className="flex gap-2 w-full sm:w-auto">
                      <div className="bg-white border border-[#1A1A1A] px-2.5 py-1 text-xs font-mono flex items-center gap-1.5 rounded-sm w-full sm:w-auto">
                        <span className="opacity-50 uppercase text-[9px] tracking-widest text-[#1A1A1A] font-bold">FROM:</span>
                        <input
                          type="text"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          className="bg-transparent font-bold focus:outline-none w-28 text-center text-emerald-800"
                          placeholder="e.g. +14155552671"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 items-stretch">
                    
                    {/* PHONE WRAPPER & CHAT CONTAINER (lg:col-span-8) */}
                    <div className="lg:col-span-7 flex flex-col items-center">
                      <div className="w-full max-w-[340px] bg-[#E8E4DF] border-[5px] border-[#1A1A1A] shadow-[8px_8px_0px_rgba(0,0,0,0.15)] flex flex-col aspect-[9/16] relative overflow-hidden rounded-xs">
                        
                        {/* PHONE UPPER DISPLAY BEZEL */}
                        <div className="bg-[#1A1A1A] text-[#F5F2ED] py-2 px-4 flex justify-between items-center text-[10px] font-mono tracking-tight">
                          <span className="font-bold">WhatsApp Business</span>
                          <div className="flex gap-1 items-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                            <span>STANDBY</span>
                          </div>
                        </div>

                        {/* CHAT CONTACT HEADER */}
                        <div className="bg-[#FAF9F5] border-b border-[#1A1A1A] p-2.5 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-[#1A1A1A] text-[#F5F2ED] flex items-center justify-center font-bold font-serif text-sm">
                              {config.name.substring(0, 1).toUpperCase()}
                            </div>
                            <div className="leading-tight">
                              <span className="text-xs font-bold block">{config.name}</span>
                              <span className="text-[9px] text-[#25D366] font-bold uppercase tracking-wider">online assistant</span>
                            </div>
                          </div>
                          
                          {/* Business Info Label */}
                          <div className="text-[8px] bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold px-1.5 py-0.5 rounded-xs uppercase tracking-tight">
                            Free bot config
                          </div>
                        </div>

                        {/* MESSAGES WALLPAPERS */}
                        <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-[#F4EFEB] relative flex flex-col scrollbar-thin">
                          <div className="text-center my-1.5">
                            <span className="text-[8px] font-mono uppercase bg-black/10 text-[#333] px-2 py-0.5 rounded-sm">
                              Today
                            </span>
                          </div>

                          {chatMessages.map((msg) => {
                            const isBot = msg.sender === "bot";
                            return (
                              <div
                                key={msg.id}
                                className={`flex flex-col max-w-[80%] ${
                                  isBot ? "self-start align-left" : "self-end align-right"
                                }`}
                              >
                                <div
                                  className={`p-2.5 text-xs rounded-lg ${
                                    isBot
                                      ? "bg-white text-[#1A1A1A] border border-[#1A1A1A]/20 shadow-xs"
                                      : "bg-[#25D366] text-black border border-emerald-700 shadow-xs self-end font-medium"
                                  }`}
                                >
                                  <p className="whitespace-pre-line leading-relaxed break-words">{msg.text}</p>
                                  <div className="flex justify-end items-center gap-1 mt-1 opacity-60 text-[8px] text-right">
                                    <span>{msg.timestamp}</span>
                                    {!isBot && <CheckCheck className="w-3 h-3 text-blue-600 block" />}
                                  </div>
                                </div>
                              </div>
                            );
                          })}

                          {isSimulatingResponse && (
                            <div className="self-start max-w-[85%] bg-white/70 text-[#444] text-[10px] italic border border-neutral-300 p-2 rounded-lg flex items-center gap-2">
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" /> {config.name} brain is thinking...
                            </div>
                          )}

                          <div ref={chatEndRef} />
                        </div>

                        {/* USER INPUT MECHANISM */}
                        <form onSubmit={handleSimulationSubmit} className="bg-[#FAF9F5] border-t border-[#1A1A1A] p-2 flex gap-1 items-center">
                          <input
                            type="text"
                            placeholder="Type client message..."
                            value={inputMessage}
                            onChange={(e) => setInputMessage(e.target.value)}
                            disabled={isSimulatingResponse}
                            className="bg-white border border-[#1A1A1A]/40 text-xs px-3 py-2 flex-1 focus:outline-none focus:border-[#1A1A1A] disabled:opacity-50"
                          />
                          <button
                            type="submit"
                            disabled={!inputMessage.trim() || isSimulatingResponse}
                            className="bg-[#1A1A1A] text-[#F5F2ED] hover:bg-[#333] p-2 border border-[#1A1A1A] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5 stroke-[2.5]" />
                          </button>
                        </form>

                      </div>
                    </div>

                    {/* SANDBOX GUIDELINES & SIMULATOR HELPERS (lg:col-span-4) */}
                    <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
                      
                      <div className="bg-[#F2EDE6] p-4 border border-[#1A1A1A] text-xs space-y-3">
                        <span className="font-mono font-bold uppercase tracking-wider text-[10px] block border-b border-[#1A1A1A] border-opacity-20 pb-1 text-[#1A1A1A]">
                          Simulate Test Cases:
                        </span>
                        
                        <p className="font-serif">Click any preset shortcut to inject simulation tests instantly:</p>

                        <div className="space-y-1.5">
                          {config.type === "ai" && (
                            <>
                              <button
                                type="button"
                                onClick={() => setInputMessage("Explain in one sentence what quantum computing is.")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 "Explain Quantum Computing"
                              </button>
                              <button
                                type="button"
                                onClick={() => setInputMessage("How are you feeling today bot? Tell me a joke.")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 "How are you? Tell me joke."
                              </button>
                            </>
                          )}

                          {config.type === "menu" && (
                            <>
                              <button
                                type="button"
                                onClick={() => setInputMessage("1")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 Reply "1" // Business Hours test
                              </button>
                              <button
                                type="button"
                                onClick={() => setInputMessage("2")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 Reply "2" // Pricing test
                              </button>
                              <button
                                type="button"
                                onClick={() => setInputMessage("9")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 Reply "9" // Default Welcomer Fallback
                              </button>
                            </>
                          )}

                          {config.type === "faq" && (
                            <>
                              {config.faqList.map((item, id) => (
                                <button
                                  key={id}
                                  type="button"
                                  onClick={() => setInputMessage(`Tell me your ${item.keyword} details please`)}
                                  className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                                >
                                  🎯 Ask about keyword: "{item.keyword}"
                                </button>
                              ))}
                              <button
                                type="button"
                                onClick={() => setInputMessage("Unknown phrase text")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 "Unknown phrase string fallback"
                              </button>
                            </>
                          )}

                          {config.type === "echo" && (
                            <>
                              <button
                                type="button"
                                onClick={() => setInputMessage("Twilio Telemetry Dry Run string 123")}
                                className="w-full text-left p-1.5 bg-white hover:bg-neutral-100 border border-neutral-300 rounded-sm font-mono text-[10px]"
                              >
                                🎯 Echo Test "String text"
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="bg-[#1A1A1A] text-white p-4 text-[11px] leading-relaxed relative">
                        <span className="font-mono text-emerald-400 uppercase text-[9px] tracking-widest font-bold block mb-1">
                          LIVE WEBHOOK ENDPOINT ACTIVED
                        </span>
                        <p className="opacity-90">
                          This code workspace is exposing a live, production-ready webhook for the real Twilio servers. Check Step 3 in the deployment guide for binding instructions.
                        </p>
                        <div className="mt-2 text-[9px] bg-black/40 text-neutral-300 p-1.5 font-mono break-all border border-neutral-700">
                          {window.location.origin}/api/whatsapp-webhook
                        </div>
                      </div>

                    </div>

                  </div>
                </motion.div>
              )}

              {/* TAB 2: LIVE CODEBASE COMPILER & EXPORTER */}
              {activeTab === "workspace" && (
                <motion.div
                  key="workspace"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="space-y-6 flex-1 flex flex-col"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#1A1A1A]/20 pb-4 gap-3 sm:gap-0">
                    <div>
                      <h3 className="font-serif font-black text-2xl tracking-tight">Active Python Server Codebase</h3>
                      <p className="text-xs text-[#555] font-serif">Code changes and updates dynamically based on the active config parameters set on the left.</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCopyCode(getSelectedCodeText(), activeCodeFile)}
                      className="px-3.5 py-1.5 bg-[#1A1A1A] text-[#F5F2ED] text-xs font-mono font-bold uppercase tracking-wider hover:bg-neutral-800 flex items-center gap-1.5 rounded-sm"
                    >
                      {isCopied === activeCodeFile ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> COPIED!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> COPY FILE
                        </>
                      )}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 flex-1 items-stretch">
                    
                    {/* ACTIVE COMPILER FILES LEFT LIST (lg:col-span-3) */}
                    <div className="lg:col-span-3 space-y-2 flex flex-row lg:flex-col flex-wrap lg:flex-nowrap gap-2 lg:gap-0">
                      {[
                        { name: "app.py", desc: "Core Python Server", required: true, size: `${(getSelectedCodeText().length / 1024).toFixed(2)} KB` },
                        { name: "requirements.txt", desc: "Dependencies setup", required: true, size: "0.12 KB" },
                        { name: ".env", desc: "Secrets configuration", required: false, size: "0.22 KB" },
                        { name: "Procfile", desc: "Cloud process descriptor", required: true, size: "0.02 KB" }
                      ].map((file) => {
                        const isCurFile = activeCodeFile === file.name;
                        return (
                          <button
                            key={file.name}
                            type="button"
                            onClick={() => setActiveCodeFile(file.name as any)}
                            className={`w-full text-left p-3 border-l-2 transition-all cursor-pointer ${
                              isCurFile 
                                ? "bg-[#1A1A1A] text-[#F5F2ED] border-l-[#25D366] font-bold" 
                                : "bg-[#F2EDE6] hover:bg-[#E8E4DF] border-l-[#1A1A1A]/20"
                            }`}
                          >
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-mono font-black">{file.name}</span>
                              {file.required && <span className="text-[8px] bg-red-800 text-white px-1 font-mono uppercase tracking-widest scale-90">Core</span>}
                            </div>
                            <span className="text-[10px] opacity-75 block leading-tight mt-1 truncate">{file.desc}</span>
                            <span className="text-[9px] font-mono block opacity-60 mt-1">{file.size}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* CODE COMPILER WINDOW (lg:col-span-9) */}
                    <div className="lg:col-span-9 flex flex-col border border-[#1A1A1A] relative rounded-xs">
                      <div className="bg-[#1A1A1A] text-[#FAF9F5] px-4 py-2 flex justify-between items-center text-xs font-mono border-b border-neutral-700">
                        <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                          Source: {activeCodeFile}
                        </span>
                        <span className="opacity-50">UTF-8 // UNIX</span>
                      </div>

                      <pre className="p-4 md:p-6 bg-[#1A1A1A] text-[#25D366] font-mono text-xs overflow-auto h-[350px] leading-relaxed scrollbar-thin flex-1 max-w-full whitespace-pre select-all">
                        <code>{getSelectedCodeText()}</code>
                      </pre>

                      <div className="bg-neutral-800 py-2.5 px-4 font-mono text-[9px] text-[#999] flex justify-between items-center border-t border-neutral-700">
                        <span>Lines: {getSelectedCodeText().split("\n").length} // Bytes: {getSelectedCodeText().length}</span>
                        <span>Press Ctrl+A to select all / Ctrl+C to copy</span>
                      </div>
                    </div>

                  </div>
                </motion.div>
              )}

              {/* TAB 3: MASTER CLOUD DEPLOYMENT MANUAL */}
              {activeTab === "guide" && (
                <motion.div
                  key="guide"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="space-y-6 flex-1 flex flex-col"
                >
                  <div className="border-b border-[#1A1A1A]/20 pb-4">
                    <h3 className="font-serif font-black text-2xl tracking-tight">Deploying Python WhatsApp Bots Free & 24/7</h3>
                    <p className="text-xs text-[#555] font-serif">Complete operational manual detailing local routing with tunneling and cloud-based deployment.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-1 items-stretch">
                    {guideSteps.map((step, idx) => (
                      <div key={idx} className="bg-[#F2EDE6] p-5 border border-[#1A1A1A] flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-center mb-2.5 border-b border-[#1A1A1A]/10 pb-1.5">
                            <span className="font-mono text-[10px] font-black uppercase text-[#1A1A1A] bg-orange-100 text-orange-900 leading-none py-1 px-1.5 rounded-sm">
                              Stage {idx + 1}
                            </span>
                            <span className="font-mono text-[10px] text-neutral-500 font-bold uppercase tracking-widest">
                              {idx === 3 ? "Continuous Server" : "Required Setup"}
                            </span>
                          </div>

                          <h4 className="font-serif font-bold text-base text-[#1A1A1A] mb-1.5">{step.title}</h4>
                          <p className="text-xs text-[#444] mb-4 font-normal font-sans leading-relaxed">{step.description}</p>
                          
                          <ul className="space-y-2">
                            {step.details.map((detail, dIdx) => (
                              <li key={dIdx} className="text-xs flex items-start gap-2 text-neutral-700">
                                <span className="font-mono text-[#1A1A1A] font-bold text-[10px] leading-none mt-0.5">•</span>
                                <span className="font-normal font-sans leading-relaxed">{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {idx === 2 && (
                          <div className="mt-4 pt-3 border-t border-[#1A1A1A]/10 flex flex-col gap-2">
                            <span className="text-[9px] font-mono font-bold text-neutral-600 uppercase">Your Sandbox Webhook URL Map:</span>
                            <div className="bg-white border border-[#1A1A1A] px-2 py-1 text-[10px] font-mono break-all rounded-xs flex justify-between items-center text-neutral-800">
                              <span>{"{NGROK_TUNNEL_URL}/webhook"}</span>
                            </div>
                          </div>
                        )}
                        
                        {idx === 3 && (
                          <div className="mt-4 pt-3 border-t border-[#1A1A1A]/10 flex flex-col gap-2">
                            <span className="text-[9px] font-mono font-bold text-neutral-600 uppercase">Target Startup Script (Start):</span>
                            <div className="bg-[#FAF9F5] border border-[#1A1A1A] px-2 py-1 text-[10px] font-mono rounded-xs flex justify-between items-center text-[#1A1A1A]">
                              <code>gunicorn app:app</code>
                              <button
                                type="button"
                                onClick={() => handleCopyCode("gunicorn app:app", "gunicorn")}
                                className="text-[9px] font-bold text-emerald-800 uppercase px-1 hover:underline"
                              >
                                {isCopied === "gunicorn" ? "Copied" : "Copy"}
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

            </AnimatePresence>
          </div>

        </section>

      </main>

      {/* FOOTER SECTION: SYSTEM LOGS TELEMETRY LEDGER */}
      <footer className="border-t border-[#1A1A1A] bg-[#FAF9F5] p-5 md:p-8">
        <div className="max-w-7xl mx-auto space-y-4">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#1A1A1A]/10 pb-3 gap-3 sm:gap-0">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#1A1A1A] stroke-[2]" />
              <h3 className="font-serif font-black text-lg tracking-tight uppercase">System Webhook Telemetry Registry</h3>
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping ml-1" />
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto font-mono text-[10px] uppercase font-bold text-[#1A1A1A]">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isScrollLocked}
                  onChange={(e) => setIsScrollLocked(e.target.checked)}
                  className="rounded-none border-[#1A1A1A]"
                />
                Scroll Lock
              </label>

              <button
                type="button"
                onClick={fetchLogs}
                className="hover:underline flex items-center gap-1 cursor-pointer bg-neutral-100 hover:bg-neutral-200 py-1 px-2.5 border border-[#1A1A1A]/30"
              >
                <RefreshCw className="w-3 h-3" /> Fetch Logs
              </button>

              <button
                type="button"
                onClick={clearServerLogs}
                className="hover:underline flex items-center gap-1 text-red-800 cursor-pointer bg-neutral-100 hover:bg-neutral-200 py-1 px-2.5 border border-[#1A1A1A]/30"
              >
                <Trash2 className="w-3 h-3 text-red-800" /> Clear Logs
              </button>
            </div>
          </div>

          {/* TELEMETRY LOGGER SCROLL VIEW */}
          <div className="bg-[#1A1A1A] p-4 text-[#25D366] font-mono text-xs overflow-y-auto h-48 border border-[#1A1A1A] space-y-2 rounded-xs select-text scrollbar-thin">
            {logs.length === 0 ? (
              <div className="text-[#999] opacity-50 italic text-center py-12">
                No telemetry data packets dispatched. Send messages inside the simulator frame to populate web hooks.
              </div>
            ) : (
              logs.map((log) => {
                const isIncoming = log.type === "incoming";
                const isOutgoing = log.type === "outgoing";
                const isSystem = log.type === "system";
                
                let labelStyle = "text-yellow-400";
                if (isIncoming) labelStyle = "text-emerald-400";
                if (isOutgoing) labelStyle = "text-sky-400 font-bold";

                return (
                  <div key={log.id} className="border-b border-neutral-800 pb-2 text-[11px] leading-relaxed">
                    <div className="flex flex-wrap justify-between items-center text-[10px] text-neutral-400 mb-1">
                      <div className="flex gap-2 items-center">
                        <span className="font-bold">[{log.timestamp.substring(11, 19)}]</span>
                        <span className={`uppercase font-black tracking-widest ${labelStyle}`}>
                          ● {log.type.toUpperCase()} // Source: {log.source.toUpperCase()}
                        </span>
                      </div>
                      <span className="opacity-60">LOG_ID: {log.id}</span>
                    </div>
                    <p className="text-[#FAF9F5] pl-4 whitespace-nowrap overflow-x-auto select-all">{log.message}</p>
                    {log.payload && (
                      <details className="mt-1 pl-4">
                        <summary className="text-[10px] text-neutral-500 cursor-pointer select-none hover:text-neutral-300">
                          Inspect Webhook Packet Payload JSON
                        </summary>
                        <pre className="p-2 bg-[#111] text-[10px] text-zinc-400 overflow-x-auto mt-1 leading-normal">
                          {JSON.stringify(log.payload, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                );
              })
            )}
            <div ref={logsEndRef} />
          </div>

          {/* LOGS CAPABILITIES STATEMENT */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center text-[10px] text-neutral-500 font-mono gap-2 sm:gap-0">
            <span>DISCLAIMER: Telemetry logs store standard server response parameters in-memory. Reset on server restart.</span>
            <span>WHATSAPP_TELEMETRY_GUEST_CHANNEL // v2.04 APPROVED STRICTLY FOR DEV</span>
          </div>

        </div>
      </footer>
      
      {/* Decorative absolute side text for ultra-wide screen Editorial vibe */}
      <span className="absolute bottom-40 right-[-48px] transform rotate-[-90deg] font-mono text-[9px] tracking-[4px] text-neutral-300 uppercase font-black pointer-events-none select-none hidden xl:block">
        MASTER BOT CONTROL DESK
      </span>
    </div>
  );
}
