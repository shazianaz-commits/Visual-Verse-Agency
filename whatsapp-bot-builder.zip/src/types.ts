export type BotType = "echo" | "faq" | "ai" | "menu";

export interface BotConfig {
  name: string;
  type: BotType;
  aiInstructions: string;
  faqList: { keyword: string; response: string }[];
  menuText: string;
}

export interface WebhookLog {
  id: string;
  timestamp: string;
  type: "incoming" | "outgoing" | "system";
  source: "simulator" | "twilio";
  message: string;
  payload: any;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "bot";
  text: string;
  timestamp: string;
}
